using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BigEnemy : MonoBehaviour
{
    
    public float speed = 3f;
    [SerializeField] public float attackDamage = 2f;
    [SerializeField] public float attackSpeed = 1f;
    public float canAttack;
    public Transform target;
    public int damage = 3;
    Animator animator;
    string currentAnimState;
    const string BigRun = "BigRun";
    const string BigIdle = "BigIdle";

    void Start()
    {
        animator = gameObject.GetComponent<Animator>();
    }
    
        
    


    void FixedUpdate()
    {
        if(target != null)
        {
            float step = speed * Time.deltaTime;
            transform.position = Vector2.MoveTowards(transform.position, target.position, step);
            ChangeAnimationState(BigRun);
            
        }
        else
        {
            ChangeAnimationState(BigIdle);
        }
    }

    void OnCollisionStay2D(Collision2D other)
    {
        if (other.gameObject.tag == "Player")
        {
            if (attackSpeed <= canAttack)
            {
               other.gameObject.GetComponent<PlayerHealth>().UpdateHealth(-attackDamage);
                canAttack = 0f;
            }
            else 
            {
                canAttack += Time.deltaTime;
            }
            
        }
    }

    void OnTriggerEnter2D(Collider2D other) 
    {
        if(other.gameObject.tag == "Player") 
        {
            target = other.transform;

            
        }
    }

    void OnTriggerExit2D(Collider2D other) 
    {
        if(other.gameObject.tag == "Player")
        {
            target = null;


        }
    }


    void ChangeAnimationState(string newState)
    {
        if (currentAnimState == newState) return;

        animator.Play(newState);

        currentAnimState = newState;
    }
}