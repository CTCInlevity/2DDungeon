using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Animation_Enemy : MonoBehaviour
{
    internal static string hasTarget = "hasTarget";
}
