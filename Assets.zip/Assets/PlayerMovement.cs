using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class PlayerMovement : MonoBehaviour
{
    // Input and nums for movement
    Rigidbody2D rb;
    float walkSpeed = 5f;
    float speedLimiter = 0.7f;
    float inputHorizontal;
    float inputVertical;

    // Animation variables
    Animator animator;
    string currentAnimState;
    const string PLAYER_IDLE = "PlayerIdle";
    const string PLAYER_WALK_FRONT = "PlayerWalkFront";
    const string PLAYER_WALK_RIGHT = "PlayerWalkRight";
    const string PLAYER_WALK_LEFT = "PlayerWalkLeft";
    const string PLAYER_WALK_BACK = "PlayerWalkBack";
    const string PLAYER_ATTACK_FRONT = "PlayerAttackFront";
    const string PLAYER_ATTACK_BACK = "PlayerAttackBack";
    const string PLAYER_ATTACK_LEFT = "PlayerAttackLeft";
    const string PLAYER_ATTACK_RIGHT = "PlayerAttackRight";
    Transform cursorTransform;

    public GameObject attackEffect;

    void Start()
    {
        //Get references
        rb = gameObject.GetComponent<Rigidbody2D>();
        animator = gameObject.GetComponent<Animator>();
        attackEffect = GameObject.Find("PlayerAttackEffect");

       // cursorTransform = GameObject.FindGameObjectWithTag("Cursor").transform;
    }

    void Update()
    {
        // Movement input
        inputHorizontal = Input.GetAxisRaw("Horizontal");
        inputVertical = Input.GetAxisRaw("Vertical");

    }

    void FixedUpdate()
    {
        if (inputHorizontal != 0 || inputVertical != 0)
        {
            // If movement is diagonal, reduce speed
            if (inputHorizontal != 0 && inputVertical != 0)
            {
                inputHorizontal *= speedLimiter; 
                inputVertical *= speedLimiter;
            }

            // If player is moving, play a movement animation for the corresponding player direction
            rb.velocity = new Vector2(inputHorizontal * walkSpeed, inputVertical * walkSpeed);

            if (inputHorizontal > 0)
            {
                ChangeAnimationState(PLAYER_WALK_RIGHT);
            }

            else if (inputHorizontal < 0)
            {
                ChangeAnimationState(PLAYER_WALK_LEFT);
            }

            else if (inputVertical > 0)
            {
                ChangeAnimationState(PLAYER_WALK_BACK);
            }

            else if (inputVertical < 0)
            {
                ChangeAnimationState(PLAYER_WALK_FRONT);
            }

        }

        else if (Input.GetKey(KeyCode.Mouse0))
        {
            // Calculate the direction vector between the player and the cursor
            Vector3 mousePos = Input.mousePosition;
            mousePos.z = Camera.main.nearClipPlane;
            Vector3 cursorTransform = Camera.main.ScreenToWorldPoint(mousePos);

            float y = Input.mousePosition.y - transform.position.y;
            float x = Input.mousePosition.x - transform.position.x;
            Vector2 direction = cursorTransform - transform.position;
            direction.Normalize();

            // Determine the angle of the direction vector in degrees
            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            // Play attack animations for each cursor direction
            GameObject copy = Instantiate(attackEffect, transform.position, Quaternion.identity);
            copy.transform.position = new Vector2(rb.position.x, rb.position.y + 1);

            //directional attack animations and attack "hitboxes" 
            if (angle <= 157.5 && angle >= 22.5)
            {
                ChangeAnimationState(PLAYER_ATTACK_BACK);
                if (angle <= 112.5 && angle >= 22.5)
                {
                    if (angle < 112.5 && angle >= 67.5)
                    {
                        copy.transform.position = new Vector2(rb.position.x, rb.position.y + 1f);
                    }
                    else
                    {
                        copy.transform.position = new Vector2(rb.position.x + 0.75f, rb.position.y + 0.75f);
                    }
                }
                else
                {
                    copy.transform.position = new Vector2(rb.position.x - 0.75f , rb.position.y + 0.75f);
                }
            }
            else if (angle <= -22.5 && angle >= -157.5)
            {
                ChangeAnimationState(PLAYER_ATTACK_FRONT);
                if (angle <= -22.5 && angle >= -112.5)
                {
                    if (angle <= -67.5 && angle >= -112.5)
                    {
                        copy.transform.position = new Vector2(rb.position.x, rb.position.y - 1.25f);
                    }
                    else
                    {
                        copy.transform.position = new Vector2(rb.position.x + 0.75f, rb.position.y - 1f);
                    }
                }
                else
                {
                    copy.transform.position = new Vector2(rb.position.x - 0.75f, rb.position.y - 1f);
                }
            }
            else if (angle < 22.5 && angle > -22.5)
            {
                ChangeAnimationState(PLAYER_ATTACK_RIGHT);
                copy.transform.position = new Vector2(rb.position.x +1f, rb.position.y - 0.125f);
            }
            else
            {
                ChangeAnimationState(PLAYER_ATTACK_LEFT);
                copy.transform.position = new Vector2(rb.position.x -1f, rb.position.y - 0.125f);
            }
            //Detect if touching enemy here
            Destroy(copy);
        }

        //When no inputs are received, play the idle animation
        else 
        {
            rb.velocity = new Vector2(0f,0f);
            ChangeAnimationState(PLAYER_IDLE);
        }
    }
    // Play provided animation
    void ChangeAnimationState(string newState)
    {
        if (currentAnimState == newState) return;

        animator.Play(newState);

        currentAnimState = newState;
    }
}